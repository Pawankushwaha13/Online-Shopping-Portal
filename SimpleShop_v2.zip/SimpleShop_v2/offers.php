<?php require_once 'includes/header.php'; ?>
<section class="section">
  <h2>Offers & Discounts</h2>
  <p>Check our special offers:</p>
  <ul>
    <li>Buy 2 get 10% off on selected items</li>
    <li>Free shipping on orders above ₹2,000</li>
    <li>Seasonal discounts up to 30%</li>
  </ul>
</section>
<?php require_once 'includes/footer.php'; ?>