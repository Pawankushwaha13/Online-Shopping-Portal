</main>
<footer class="site-footer">
  <div class="container">
    <p>&copy; <?php echo date('Y'); ?> SimpleShop — All rights reserved.</p>
  </div>
</footer>
</body>
</html>
