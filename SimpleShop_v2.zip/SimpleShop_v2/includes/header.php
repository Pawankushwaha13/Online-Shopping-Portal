<?php
require_once __DIR__ . '/../config/db.php';
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>SimpleShop</title>
  <link rel="stylesheet" href="/SimpleShop_v2/assets/styles.css">
</head>
<body>
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="/SimpleShop_v2/index.php">SimpleShop</a>
    <nav class="main-nav">
      <a href="/SimpleShop_v2/index.php">Home</a>
      <a href="/SimpleShop_v2/index.php#menu">Menu</a>
      <a href="/SimpleShop_v2/about.php">About</a>
      <a href="/SimpleShop_v2/offers.php">Offers</a>
      <a href="/SimpleShop_v2/contact.php">Contact</a>
    </nav>
    <div class="nav-right">
      <?php if(isLoggedIn()): ?>
        <a class="cart-link" href="/SimpleShop_v2/cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a>
        <span class="username">Hi, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
        <a href="/SimpleShop_v2/logout.php" class="btn-link">Logout</a>
      <?php else: ?>
        <a href="/SimpleShop_v2/signup.php" class="btn-link">Signup</a>
        <a href="/SimpleShop_v2/login.php" class="btn-link">Login</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main class="site-main container">
