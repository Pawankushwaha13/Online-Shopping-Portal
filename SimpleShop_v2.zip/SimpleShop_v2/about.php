<?php require_once 'includes/header.php'; ?>
<section class="section">
  <h2>About SimpleShop</h2>
  <p>SimpleShop is a demo online shopping portal built for learning and quick prototyping. We showcase products, allow users to signup/login, add items to a session-based cart and view them.</p>
  <p>This project is meant for educational purposes.</p>
</section>
<?php require_once 'includes/footer.php'; ?>